import Foundation

protocol Feasible {
    var done: Bool { get }
}

class CheckListElement: CustomStringConvertible, Feasible{
    var text: String
    var day: String
    var done: Bool
    
    var description: String {
        return  day + " " + text + " -> " + (done ? "Gotowe" : "Do wykonania")
    }
    
    
    init(text: String, done: Bool, day: String) {
        self.text = text
        self.done = done
        self.day = day
    }
    
    init() {
        text = "Zadanie"
        done = false
        day = "Poniedziałek"
    }
    
    func setDone(done: Bool) {
        self.done = done
    }
}





var obiekt = CheckListElement()
var obiekt2 = CheckListElement(text: "malowanie", done: true, day: "Czwartek")
print(obiekt)
print(obiekt2)

